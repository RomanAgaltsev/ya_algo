/*
Яндекс Практикум
Алгоритмы и структуры данных
58 когорта
Агальцев Роман

Задача - B. Ловкость рук
Отчет - https://contest.yandex.ru/contest/22450/run-report/110483578/
*/

package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

// getPoint - определяет для переданной комбинации поля, k и t, заработан балл или нет
func getPoint(field [][]int, k int, t int) int {
	// Счетчик цифр на поле, равных t
	numCount := 0
	// Обходим поле и считаем количество цифр, равных t
	for _, line := range field {
		for _, val := range line {
			if val == t {
				numCount += 1
			}
		}
	}
	// По условию задачи играют двое, поэтому 2 * k
	// Надо не только сравнить счетчик и 2 * k,
	// но и проверить numCount на 0 - нет ни одной нужной цифры на поле 
	if numCount != 0 && 2 * k >= numCount {
		// Балл заработан
		return 1
	}
	// Балл не заработан
	return 0
}

// getMaxNumber - возвращает максимальную цифру на поле
func getMaxNumber(field [][]int) int {
	maxNumber := 0
	for _, line := range field {
		for _, val := range line {
			if val > maxNumber {
				maxNumber = val
			}
		}
	}
	return maxNumber
}

// GetPpoints - по переданным полю и k подсчитывает количество заработанных баллов
func GetPpoints(field [][]int, k int) int {
	// Счетчик заработанных баллов
	points := 0
	// Получаем максимальную цифру, чтобы не делать лишних итераций - баллов на них не будет
	maxNumber := getMaxNumber(field)
	// Обходим поле
	for t := 1; t <= maxNumber; t++ {
		// Суммируем счетчик и результат итерации
		points +=getPoint(field, k, t)
	}
	return points
}

func main() {
	scanner := makeScanner()
	k := readInt(scanner)
	field := readField(scanner)
	fmt.Print(GetPpoints(field, k))
}

func makeScanner() *bufio.Scanner {
	const maxCapacity = 3 * 1024 * 1024
	buf := make([]byte, maxCapacity)
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Buffer(buf, maxCapacity)
	return scanner
}

func readField(scanner *bufio.Scanner) [][]int {
	field := make([][]int, 0)
	for i := 0; i < 4; i++ {
		scanner.Scan()
		listString := strings.Split(scanner.Text(), "")
		arr := make([]int, len(listString))
		for j := 0; j < len(listString); j++ {
			arr[j], _ = strconv.Atoi(listString[j])
		}
		field = append(field, arr)
	}
	return field
}

func readInt(scanner *bufio.Scanner) int {
	scanner.Scan()
	stringInt := scanner.Text()
	res, _ := strconv.Atoi(stringInt)
	return res
}