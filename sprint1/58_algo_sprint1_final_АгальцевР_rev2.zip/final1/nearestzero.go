/*
Яндекс Практикум
Алгоритмы и структуры данных
58 когорта
Агальцев Роман

Задача - A. Ближайший ноль

Отчеты:
- Ревью 1 - https://contest.yandex.ru/contest/22450/run-report/110431660/
- Ревью 2 - https://contest.yandex.ru/contest/22450/run-report/110567531/

Алгоритмическая сложность:
Память - O(n)
Предполагаю, что за n принимаем количество элементов в слайсе.
При увеличении слайса будет увеличиваться память, требуемая для его хранения.
Для решения используем:
- Слайс - память для него зависит от количества элементов. При увеличении входных данныъ память будет расти линейно;
- Несколько переменных - счетчики. Для них память всегда будет константой. При увеличении поля расти не будет;
Таким образом, память, требуемая для решения задачи, будет линейно зависеть от размера входных данных.

Вычислительная - O(n)
Опять же, за n принимаем количество элементов в слайсе.
В ходе решения:
- Чтение ввода в слайс - n, чтение выполяется 1 раз. При увеличении ввода будет расти линейно.
- Обход слайса и вычисление ближайших нулей - n для обхода слайса указателем, плюс на каждую из дистанций (между нулями или началом/концом слайса) "дистанция/2".
Таким образом, можно сказать, что вычислительная сложность будет равна O(n + (сумма "дистанция/2" по всем дистанциям)).
Но берем максимальную и отбрасываем коэффициенты и константы - O(n).

*/

package main

import (
	"bufio"
	"os"
	"strconv"
	"strings"
)

// GetNearestZeros - возвращает слайс с ближайшими нулями
// Название функции с большой буквы, потому что IDE ругалась на маленькую в файле тестов
func GetNearestZeros(houseNumbers *[]int) []int {
	// Размер входного слайса сохраним в переменной, чтобы не получать несколько раз
	houseNumbersLen := len(*houseNumbers)
	// Для экономии памяти используем тот же слайс
	// Новая переменная - для наглядности
	nearestZeros := *houseNumbers
	// Указатель на текущую позицию в слайсе
	curr := -1
	// Дистанция, которую прошел указатель с начала слайса или предыдущего 0
	dist := -1
	// Обход указателем всего слайса
	for curr < houseNumbersLen-1 {
		// Указатель делает 1 шаг
		curr += 1
		// Расстояние с начала слайса или предыдущего 0 увеличивается на 1
		dist += 1
		// Проверяем не нашел ли указатель 0 или не дошел ли до конца слайса
		if nearestZeros[curr] == 0 || curr == houseNumbersLen-1 {
			// Указатель нашел 0 или дошел до конца слайса
			// Обходим пройденную дистанцию
			// Используя два счетчика можно обойти дистанцию за количество шагов в два раза меньшее, чем дистанция
			for i, j := 0, dist; i <= j; i, j = i+1, j-1 {
				// Счетчика два, за одну итерацию можем обработать сразу два элемента слайса
				// Использую switch обрабатываем возможные ситуации
				switch {
				// В начале дистанции 0, в конце дистанции не 0
				case nearestZeros[curr-dist] == 0 && nearestZeros[curr] != 0:
					nearestZeros[curr-j] = i
					nearestZeros[curr-i] = j
				// В начале дистанции не 0, в конце дистанции 0
				case nearestZeros[curr-dist] != 0 && nearestZeros[curr] == 0:
					nearestZeros[curr-j] = j
					nearestZeros[curr-i] = i
				// В начале дистанции 0, в конце дистанции 0
				case nearestZeros[curr-dist] == 0 && nearestZeros[curr] == 0:
					nearestZeros[curr-j] = i
					nearestZeros[curr-i] = i
				}
			}
			// Обнуляем пройденную дистанцию
			dist = 0
		}
	}
	return nearestZeros
}

func main() {
	scanner := makeScanner()
	readInt(scanner)
	houseNumbers := readArray(scanner)
	printArray(GetNearestZeros(&houseNumbers))
}

func makeScanner() *bufio.Scanner {
	const maxCapacity = 10 * 1024 * 1024
	buf := make([]byte, maxCapacity)
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Buffer(buf, maxCapacity)
	return scanner
}

func readArray(scanner *bufio.Scanner) []int {
	scanner.Scan()
	listString := strings.Split(scanner.Text(), " ")
	arr := make([]int, len(listString))
	for i := 0; i < len(listString); i++ {
		arr[i], _ = strconv.Atoi(listString[i])
	}
	return arr
}

func readInt(scanner *bufio.Scanner) int {
	scanner.Scan()
	stringInt := scanner.Text()
	res, _ := strconv.Atoi(stringInt)
	return res
}

func printArray(arr []int) {
	writer := bufio.NewWriter(os.Stdout)
	for i := 0; i < len(arr); i++ {
		writer.WriteString(strconv.Itoa(arr[i]))
		writer.WriteString(" ")
	}
	writer.Flush()
}